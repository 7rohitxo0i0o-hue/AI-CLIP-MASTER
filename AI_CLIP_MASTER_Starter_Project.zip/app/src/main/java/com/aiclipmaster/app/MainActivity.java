package com.aiclipmaster.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 101;
    private TextView selectedVideo;

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private TextView text(String value, int size) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        return b;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(22), dp(30), dp(22), dp(22));
        page.setBackgroundColor(0xFF10131D);

        TextView title = text("AI CLIP MASTER", 28);
        title.setTypeface(null, 1);
        page.addView(title, new LinearLayout.LayoutParams(-1, dp(62)));

        TextView subtitle = text("YOUR FREE AI VIDEO CLIPPING STUDIO", 12);
        subtitle.setTextColor(0xFFB9C3D8);
        page.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(36)));

        Button upload = button("1. Select video from phone");
        page.addView(upload, new LinearLayout.LayoutParams(-1, dp(58)));

        selectedVideo = text("No video selected", 14);
        selectedVideo.setTextColor(0xFFB9C3D8);
        page.addView(selectedVideo, new LinearLayout.LayoutParams(-1, dp(52)));

        String[] features = {
            "AI Auto Clips  •  Coming in next build",
            "Hindi + English Captions  •  Planned",
            "Vertical 9:16 Reframe  •  Planned",
            "Multiple Shorts Export  •  Planned"
        };
        for (String feature : features) {
            TextView item = text(feature, 14);
            item.setBackgroundColor(0xFF202638);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54));
            p.setMargins(0, dp(7), 0, dp(7));
            page.addView(item, p);
        }

        TextView note = text("Starter version 0.1\nFree and open-source project", 12);
        note.setTextColor(0xFF9DAAC3);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(-1, dp(64));
        noteParams.topMargin = dp(18);
        page.addView(note, noteParams);

        setContentView(page);

        upload.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("video/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(intent, PICK_VIDEO);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                selectedVideo.setText("Selected: " + uri.getLastPathSegment());
                Toast.makeText(this, "Video selected. AI processing will be added next.", Toast.LENGTH_LONG).show();
            }
        }
    }
}
